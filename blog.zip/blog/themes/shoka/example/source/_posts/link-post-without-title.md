date: 2013-12-24 23:44:13
link: http://www.google.com/
---

This is a link post without a title. The title should be the link with or without protocol. Clicking on the link should open [Google](http://www.google.com/) in a new tab or window.