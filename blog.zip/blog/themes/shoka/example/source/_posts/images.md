title: Images
date: 2013-12-26 22:46:49
cover: https://cdn.jsdelivr.net/gh/amehime/shoka@latest/images/avatar.jpg
---

This is a image test post.

![](/assets/wallpaper-2572384.jpg)

![Caption](/assets/wallpaper-2311325.jpg)

![](/assets/wallpaper-878514.jpg)

![Small Picture](https://placehold.it/350x150.jpg)
